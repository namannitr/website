import MySQLdb

class DbConnect():
    db = MySQLdb.connect("localhost","root","Nam@1695!!","eko_Project") 
#write db password in place of password
