print "Naman Agarwal"
