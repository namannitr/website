def get_credentials():
	return ("919873866541", " cJplrZour0J2UU8qXqmvJrA7UXg=")
