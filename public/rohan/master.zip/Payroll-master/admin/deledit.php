<?php 
$op="edit";
 ?>