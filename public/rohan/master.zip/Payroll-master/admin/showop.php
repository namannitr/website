<head>
    <script type="text/javascript" src="scripts/ajax.js"></script>
</head>
<?php
    echo '<td>Enter Employee\'s First Name:</td>';
    echo '<td><input type="text" value="" name="search" onkeyup="findemp(this.value);"></td>';
    echo '<input type="hidden" value="name" name="op">';
?>
