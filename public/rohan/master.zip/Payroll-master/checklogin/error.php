<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>District Barnala</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="../css/coin-slider.css" />
<link rel="stylesheet" type="text/css" href="../css/superfish.css" media="screen" />
<script type="text/javascript" src="../js/menu.js"></script>
<script type="text/javascript" src="../js/footer.js"></script>
<script type="text/javascript" src="../js/sidebar.js"></script>
<script type="text/javascript" src="../js/cufon-yui.js"></script>
<script type="text/javascript" src="../js/cufon-quicksand.js"></script>
<script type="text/javascript" src="../js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="../js/script.js"></script>
<script type="text/javascript" src="../js/coin-slider.min.js"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="logo">
        <h1><a href="../index.php">Payroll Managament System<small>A Sidhu const. ERP System </small></a></h1>
      </div>

      <div class="clr"></div>


<br/>
<div class="clr"></div>

      <div class="clr"></div>
    </div>
  </div>
  <div class="content" >
    <div class="content_resize">
      <div class="mainbar" style=" background-image: url('images/invisible.jpg'); background-position: center; background-repeat: no-repeat;">
        <div class="article" style="height: 300px;">
        <br />

       <p style="font-size:18px;" align="center">
            Sorry You are not authorised. OR Your Session was expired<br/><br/>
            <a href="../index.php">Get Back to Login</a>
        </p>
          <br/>
        </div>


      </div>
      
      <div class="clr"></div>
    </div>
  </div>

    <br />
    <div id="disclaimer">
    <script type="text/javascript">footere();</script>
    </div>

</div>
</body>
</html>
