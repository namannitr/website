function footere(){
      document.write('<div id="content">');
      
      
     document.write('Application Data Provided By: Sidhu Construction Company<br />');
    document.write('Project Designed, Developed &amp; Maintained By: <a href="http://www.parveenarora.in"Parveen Arora</a>');

document.write('<div id="copy">');
document.write('<a href="disclaimer.html">(Disclaimer)</a>&nbsp;&nbsp;<a href="privacy.html">(Privacy Statement)</a>&nbsp;&nbsp;<a href="copyright.html">(Copyright)</a>');
    document.write('</div>');
    document.write('</div>');
}
