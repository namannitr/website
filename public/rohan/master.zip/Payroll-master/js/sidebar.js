function sidee(){
    document.write('<h2 class="star"><span>News &amp; Updates</span></h2><div class="clr"></div><ul class="sb_menu">');
    document.write('<!--<li><a href="#">&raquo; Home</a></li></ul><br /> -->');
    document.write('<img src="gallery/side.jpg" width="235" height="250" border="0" usemap="#map" />');
document.write('<map name="map">');
document.write('<!-- #$AUTHOR:inderjeet -->');
document.write('<area shape="rect" coords="10,13,90,81" alt="Directory" href="images/numbers.pdf" />');
document.write('<area shape="rect" coords="148,14,226,75" alt="Gallery" href="places.html" />');
document.write('<area shape="rect" coords="7,136,82,197" alt="Contact" href="contact.html" />');
document.write('<area shape="rect" coords="149,136,224,196" alt="Forms" href="form.html" />');
document.write('</map>');
}
function sidep(){
     document.write('<h2 class="star"><span>News &amp; Updates</span></h2><div class="clr"></div><ul class="sb_menu">');
    document.write('<!--<li><a href="#">&raquo; Home</a></li></ul><br /> -->');
    document.write('<img src="../gallery/sidep.jpg" width="235" height="250" border="0" usemap="#map2" />');
document.write('<map name="map2">');
document.write('<!-- #$AUTHOR:inderjeet -->');
document.write('<area shape="rect" coords="10,13,90,81" alt="Directory" href="../images/numbers.pdf" />');
document.write('<area shape="rect" coords="148,14,226,75" alt="Gallery" href="places.html" />');
document.write('<area shape="rect" coords="7,136,82,197" alt="Contact" href="contact.html" />');
document.write('<area shape="rect" coords="149,136,224,196" alt="Forms" href="form.html" />');
document.write('</map>');
}