<?php
class Home extends Controller
{
    public function index(){ 
            echo "main page";  
    }
}
?>
