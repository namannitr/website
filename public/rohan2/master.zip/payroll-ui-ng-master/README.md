jQuery & AngularJs Test
=======================
You do not need a server to run this, just run the index on your browser.
## Scripts Used
- jQuery 
- jQuery-ui
- [jQuery.simplr-grid](https://github.com/samweru/simplr-grid)
- AngularJs
- Angular UI Router
- Angular Mocks
- [Jasmine](https://jasmine.github.io) Test Framework
- [Faker.js](https://github.com/marak/Faker.js)
- [TaffyDB](https://github.com/typicaljoe/taffydb) In-Memory DB

