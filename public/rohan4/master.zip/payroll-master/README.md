# Payroll
Payroll is an application to maintain your company's employee records, salary details and leave applications without any hassle.
